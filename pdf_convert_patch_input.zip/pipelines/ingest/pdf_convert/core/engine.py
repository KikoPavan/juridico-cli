from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol, Sequence

# -----------------------------
# Protocols (contratos)
# -----------------------------


class ExtractionMetaLike(Protocol):
    pages_total: int
    primary_tool: str


ExtractPagesFn = Callable[[Path], tuple[list[str], ExtractionMetaLike]]


class RulesProtocol(Protocol):
    # limpeza e parsing
    def clean_page_text(self, raw_page_text: str) -> str: ...

    def extract_metadata(self, *, full_text: str, stem: str) -> Mapping[str, Any]: ...

    # front-matter
    def build_front_matter_str(
        self,
        *,
        meta: Mapping[str, Any],
        pages_total: int,
        source_pdf: str,
        extraction: ExtractionMetaLike,
    ) -> str: ...

    def build_front_matter_dict(
        self,
        *,
        meta: Mapping[str, Any],
        pages_total: int,
        source_pdf: str,
        extraction: ExtractionMetaLike,
    ) -> Mapping[str, Any]: ...

    # report
    def build_report_markdown(
        self,
        *,
        fname: str,
        fm_dict: Mapping[str, Any],
        pages_total: int,
        primary_tool: str,
    ) -> str: ...

    # util
    def now_utc_iso_z(self) -> str: ...


# -----------------------------
# Escrita (MD/JSON/REPORT)
# -----------------------------


def _atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    tmp.replace(path)


def _atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def write_markdown(
    out_path: Path, front_matter: str, cleaned_pages: Sequence[str]
) -> None:
    parts: list[str] = []
    parts.append(front_matter.rstrip() + "\n\n")
    for i, page_text in enumerate(cleaned_pages, start=1):
        parts.append(f"<!-- PAGE: {i} -->\n")
        parts.append(f"[[Pág. {i}]]\n")
        parts.append(page_text.rstrip() + "\n\n")
    _atomic_write_text(out_path, "".join(parts))


# -----------------------------
# Engine
# -----------------------------


@dataclass(frozen=True)
class EngineIO:
    dir_pdf: Path
    dir_md: Path
    dir_json: Path
    dir_rep: Path


@dataclass(frozen=True)
class EngineMove:
    # Se quiser arquivar/mover PDFs após processar
    success_dir: Path | None = None
    fail_dir: Path | None = None


@dataclass(frozen=True)
class EngineResult:
    ok: int
    fail: int


def _move_file(src: Path, dst_dir: Path) -> None:
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / src.name
    # shutil.move funciona entre filesystems
    shutil.move(str(src), str(dst))


def convert_one_pdf(
    pdf_path: Path,
    *,
    io: EngineIO,
    rules: RulesProtocol,
    extract_pages: ExtractPagesFn,
) -> None:
    fname = pdf_path.name
    stem = pdf_path.stem

    # 1) Extração
    pages_raw, meta_extract = extract_pages(pdf_path)

    # 2) Limpeza
    cleaned_pages = [rules.clean_page_text(t) for t in pages_raw]

    # remove cabeçalho repetido a partir da página 2 (opcional)
    if len(cleaned_pages) > 1:
        cleaned_pages = [cleaned_pages[0]] + [
            rules.strip_repeated_header_block(p) for p in cleaned_pages[1:]
        ]

    raw_full_text = "\n".join(pages_raw)
    clean_full_text = "\n".join(cleaned_pages)

    meta = rules.extract_metadata(
        full_text=clean_full_text,
        raw_full_text=raw_full_text,
        stem=stem,
    )

    # 3) Metadados do modelo (rules)
    meta = rules.extract_metadata(
        full_text=clean_full_text,
        raw_full_text=raw_full_text,
        stem=stem,
    )

    # 4) Front matter (str + dict)
    source_pdf_norm = str(pdf_path).replace("\\", "/")

    fm_str = rules.build_front_matter_str(
        meta=meta,
        pages_total=meta_extract.pages_total,
        source_pdf=source_pdf_norm,
        extraction=meta_extract,
    )

    fm_dict = rules.build_front_matter_dict(
        meta=meta,
        pages_total=meta_extract.pages_total,
        source_pdf=source_pdf_norm,
        extraction=meta_extract,
    )

    # 5) Paths de saída
    out_md = io.dir_md / f"{stem}.md"
    out_json = io.dir_json / f"{stem}.json"
    out_rep = io.dir_rep / f"{stem}.report.md"

    # 6) MD
    write_markdown(out_md, fm_str, cleaned_pages)

    # 7) JSON
    payload = {
        "front_matter": dict(fm_dict),
        "pages": [{"page": i + 1, "text": t} for i, t in enumerate(cleaned_pages)],
        "generated_at": rules.now_utc_iso_z(),
    }
    _atomic_write_json(out_json, payload)

    # 8) REPORT
    report_md = rules.build_report_markdown(
        fname=fname,
        fm_dict=dict(fm_dict),
        pages_total=meta_extract.pages_total,
        primary_tool=getattr(meta_extract, "primary_tool", "unknown"),
    )
    _atomic_write_text(out_rep, report_md)


def run_batch(
    *,
    io: EngineIO,
    pdf_files: Sequence[str],
    rules: RulesProtocol,
    extract_pages: ExtractPagesFn,
    limit: int | None = None,
    mover: EngineMove = EngineMove(),
) -> EngineResult:
    if not io.dir_pdf.is_dir():
        raise SystemExit(f"Pasta de entrada não encontrada: {io.dir_pdf}")

    files = [f for f in pdf_files if f.lower().endswith(".pdf")]
    if limit is not None:
        files = files[: max(0, int(limit))]

    if not files:
        print(f"Nenhum arquivo PDF encontrado em {io.dir_pdf}.")
        return EngineResult(ok=0, fail=0)

    print(f"Iniciando processamento de {len(files)} PDF(s) em {io.dir_pdf}...")
    print("---------------------------------------------------")

    ok = 0
    fail = 0

    for pdf_fname in files:
        pdf_path = io.dir_pdf / pdf_fname
        print(f"Processando: {pdf_fname}...")
        try:
            convert_one_pdf(pdf_path, io=io, rules=rules, extract_pages=extract_pages)
            ok += 1
            print(f"  ✅ Sucesso: {pdf_fname}")
            if mover.success_dir is not None:
                _move_file(pdf_path, mover.success_dir)
        except Exception as e:
            fail += 1
            print(f"  ❌ Erro ao processar {pdf_fname}: {e}")
            if mover.fail_dir is not None and pdf_path.exists():
                _move_file(pdf_path, mover.fail_dir)

    print("---------------------------------------------------")
    print(f"Processamento concluído. Sucesso: {ok}, Falhas: {fail}")
    print("Resultados salvos em:")
    print(f"  Markdown: {io.dir_md}")
    print(f"  JSON: {io.dir_json}")
    print(f"  Relatórios: {io.dir_rep}")

    return EngineResult(ok=ok, fail=fail)


def now_utc_iso_z_default() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
