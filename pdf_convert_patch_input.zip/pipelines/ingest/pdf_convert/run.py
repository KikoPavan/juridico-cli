#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import Any, Dict, List

import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def find_project_root(start: Path) -> Path:
    """Sobe diretórios até encontrar pyproject.toml (raiz do juridico-cli)."""
    start = start.resolve()
    for p in [start] + list(start.parents):
        if (p / "pyproject.toml").exists():
            return p
    return start


def load_yaml(path: Path) -> Dict[str, Any]:
    if not path.exists():
        raise SystemExit(f"Arquivo de profile não encontrado: {path}")
    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    if not isinstance(data, dict):
        raise SystemExit(f"Profile inválido (YAML não é um objeto): {path}")
    return data


def resolve_profile_yaml(project_root: Path, profile_arg: str) -> Path:
    """
    Aceita:
      - Nome do profile: bj_juris_stj  -> pipelines/ingest/pdf_convert/profiles/bj_juris_stj/profile.yaml
      - Caminho relativo: pipelines/.../profile.yaml
      - Caminho absoluto: /home/.../profile.yaml
    """
    p = Path(profile_arg)
    if p.is_absolute():
        return p

    if profile_arg.endswith(".yaml") or "/" in profile_arg or "\\" in profile_arg:
        return (project_root / profile_arg).resolve()

    return (
        project_root
        / "pipelines"
        / "ingest"
        / "pdf_convert"
        / "profiles"
        / profile_arg
        / "profile.yaml"
    ).resolve()


def list_pdfs(dir_pdf: str, limit: int | None = None) -> List[str]:
    files = sorted([f for f in os.listdir(dir_pdf) if f.lower().endswith(".pdf")])
    if limit is not None and limit > 0:
        return files[:limit]
    return files


def import_profile_script(script_path: Path, module_name: str):
    import importlib.util
    import sys

    if not script_path.exists():
        raise SystemExit(f"Script não encontrado: {script_path}")

    spec = importlib.util.spec_from_file_location(module_name, str(script_path))
    if spec is None or spec.loader is None:
        raise SystemExit(f"Não foi possível carregar o script: {script_path}")

    mod = importlib.util.module_from_spec(spec)

    # Necessário (ex.: dataclasses em Python 3.12 com import dinâmico)
    sys.modules[module_name] = mod

    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Runner do conversor PDF -> MD/JSON/REPORT (carrega profile.yaml e chama o script do profile)."
    )
    parser.add_argument(
        "--profile",
        default="bj_juris_stj",
        help="Nome do profile (ex.: bj_juris_stj) ou caminho para profile.yaml.",
    )
    parser.add_argument(
        "--script",
        default=None,
        help="Caminho para o script Python do profile (default: convert_stj.py no mesmo diretório do profile.yaml).",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=0,
        help="Processa só os primeiros N PDFs (0 = todos).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Mostra caminhos e lista de PDFs, mas não executa a conversão.",
    )

    args = parser.parse_args()

    project_root = find_project_root(Path(__file__).resolve().parent)
    profile_yaml = resolve_profile_yaml(project_root, args.profile)
    cfg = load_yaml(profile_yaml)

    dirs = cfg.get("dirs") or {}
    if not isinstance(dirs, dict):
        raise SystemExit(
            f"Config inválida: 'dirs' deve ser um objeto em {profile_yaml}"
        )

    for key in ("pdf", "md", "json", "rep"):
        if key not in dirs:
            raise SystemExit(f"Config inválida em {profile_yaml}: faltou dirs.{key}")

    def abs_path(rel_or_abs: str) -> str:
        p = Path(rel_or_abs)
        if p.is_absolute():
            return str(p)
        return str((project_root / rel_or_abs).resolve())

    DIR_PDF = abs_path(str(dirs["pdf"]))
    DIR_MD = abs_path(str(dirs["md"]))
    DIR_JSON = abs_path(str(dirs["json"]))
    DIR_REP = abs_path(str(dirs["rep"]))

    for p in (DIR_PDF, DIR_MD, DIR_JSON, DIR_REP):
        os.makedirs(p, exist_ok=True)

    pdf_files = list_pdfs(
        DIR_PDF, limit=args.limit if args.limit and args.limit > 0 else None
    )

    print("Projeto:", project_root)
    print("Profile:", profile_yaml)
    print("PDFs (entrada):", DIR_PDF)
    print("Saída MD:", DIR_MD)
    print("Saída JSON:", DIR_JSON)
    print("Relatórios:", DIR_REP)
    print("Encontrados:", len(pdf_files))
    if pdf_files:
        print("\n".join(pdf_files[:20]) + ("\n..." if len(pdf_files) > 20 else ""))

    if args.dry_run:
        return 0

    # Resolve script do profile
    if args.script:
        script_path = (
            (project_root / args.script).resolve()
            if not Path(args.script).is_absolute()
            else Path(args.script)
        )
    else:
        # default: convert_stj.py no mesmo diretório do profile.yaml
        script_path = profile_yaml.parent / "convert_stj.py"

    profile_name = profile_yaml.parent.name

    # Script principal do profile (ex.: convert_stj.py)
    mod = import_profile_script(script_path, module_name=f"pdf_profile_{profile_name}")

    # Script de regras do profile (rules.py)
    rules_path = profile_yaml.parent / "rules.py"
    rules_mod = import_profile_script(
        rules_path, module_name=f"pdf_rules_{profile_name}"
    )

    # Parâmetros opcionais do profile.yaml
    document_type = cfg.get("document_type", "base_juridica")
    doc_subtype = cfg.get("doc_subtype", "jurisprudencia")
    language = cfg.get("language", "pt-BR")

    # Instancia RULES (modelo)
    if not hasattr(rules_mod, "STJRules"):
        raise SystemExit(f"rules.py não expõe STJRules(): {rules_path}")

    RULES = rules_mod.STJRules(
        document_type=document_type,
        doc_subtype=doc_subtype,
        language=language,
    )

    # Injeta variáveis globais esperadas pelo script (equivalente à Célula 1 do Colab)
    mod.DIR_PDF = DIR_PDF
    mod.DIR_MD = DIR_MD
    mod.DIR_JSON = DIR_JSON
    mod.DIR_REP = DIR_REP
    mod.pdf_files = pdf_files
    mod.RULES = RULES

    # Executa
    if not hasattr(mod, "main_processing_loop"):
        raise SystemExit(
            f"O script {script_path} não possui a função main_processing_loop()."
        )

    mod.main_processing_loop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
