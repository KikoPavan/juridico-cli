#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import json  # Adicionado para saída JSON
import os  # Adicionado para operações de caminho
import re
from dataclasses import dataclass
from datetime import (  # datetime.timezone adicionado para datetime.UTC
    datetime,
    timezone,
)
from pathlib import Path
from typing import List, Optional

import fitz  # PyMuPDF
import pdfplumber  # Adicionado para fallback
import yaml  # Adicionado para saída YAML

# -----------------------------
# Limpeza: rodapé + quebras
# -----------------------------

_FOOTER_START_RE = re.compile(
    r"^\s*Documento\s+eletrônico\s+VDA[0-9A-Z]+\b", re.IGNORECASE
)
_FOOTER_LINE_RE = re.compile(
    r"^\s*(?:Documento\s+eletrônico\s+VDA[0-9A-Z]+\b.*|Signatário\(a\)\,s*:\s*.*|Assinado\s+em\s*:\s*.*|Código\s+de\s+Controle\s+do\s+Documento\s*:\s*.*)\s*$",
    re.IGNORECASE,
)

_LABELS = (
    "RELATOR",
    "AGRAVANTE",
    "AGRAVADO",
    "ADVOGADO",
    "ADVOGADOS",
    "OUTRO NOME",
    "RECORRENTE",
    "RECORRIDO",
    "ASSUNTO",
    "PRESIDENTE DA SESSÃO",
    "SECRETÁRIO",
)
_LABEL_JOIN_RE = re.compile(
    r"(?m)^(" + "|".join(re.escape(x) for x in _LABELS) + r")\s*\n\s*:\s*",
    flags=re.IGNORECASE,
)

# headings curtas que devem manter quebra (uma linha só)
_HEADING_RE = re.compile(
    r"^(EMENTA|ACÓRDÃO|RELATÓRIO|VOTO|TERMO|TERMO DE JULGAMENTO|AUTUAÇÃO)\s*$",
    re.IGNORECASE,
)

# linhas “estruturais” (não reflow agressivo)
_STRUCTURAL_LINE_RE = re.compile(
    r"^(?:\[\[Pág\.\s*\d+\]\]|AgInt\b|REsp\b|AREsp\b|AGRAVO\b|EMBARGOS\b|\(|\d+\.)",
    re.IGNORECASE,
)


def _strip_footer_lines(raw: str) -> str:
    """
    Remove rodapés STJ que começam em 'Documento eletrônico VDA...'
    e/ou linhas típicas de assinatura eletrônica.
    Estratégia:
      1) Se achar início do rodapé, corta o texto dali até o final.
      2) Também remove linhas soltas de rodapé (caso venham espalhadas).
    """
    text = raw.replace("\r\n", "\n").replace("\r", "\n")

    # Corta a partir do primeiro "Documento eletrônico VDA..."
    lines = text.split("\n")
    cut_idx: Optional[int] = None
    for i, ln in enumerate(lines):
        if _FOOTER_START_RE.match(ln):
            cut_idx = i
            break
    if cut_idx is not None:
        lines = lines[:cut_idx]

    # Remove linhas típicas de rodapé remanescentes
    cleaned: List[str] = []
    for ln in lines:
        if _FOOTER_LINE_RE.match(ln):
            continue
        cleaned.append(ln)

    return "\n".join(cleaned)


def _fix_label_colon_breaks(text: str) -> str:
    """
    Corrige padrão:
      RELATOR
      : MINISTRO ...
    para:
      RELATOR : MINISTRO ...
    """
    return _LABEL_JOIN_RE.sub(lambda m: f"{m.group(1).upper()} : ", text)


def _normalize_spaces(text: str) -> str:
    # remove trailing spaces, normaliza espaços múltiplos (sem destruir indentação útil)
    lines = [ln.rstrip() for ln in text.split("\n")]
    return "\n".join(lines)


def _is_all_caps_like(s: str) -> bool:
    s2 = re.sub(r"[^A-Za-zÀ-ÿÇÁÉÍÓÚÂÊÔÃÕÜ]", "", s)
    if not s2:
        return False
    return s2.upper() == s2 and len(s2) >= 4


def _reflow_block(lines: List[str]) -> str:
    """
    Reflow de um bloco (sem linhas vazias).
    - Preserva headings.
    - Preserva listas enumeradas '1.' como linhas (com continuação colada).
    - Caso geral: junta linhas com espaço.
    """
    if not lines:
        return ""

    if len(lines) == 1:
        return lines[0]

    # heading puro
    if len(lines) == 1 and _HEADING_RE.match(lines[0].strip()):
        return lines[0].strip()

    # bloco contém lista numerada
    if any(re.match(r"^\d+\.\s+", ln) for ln in lines):
        out: List[str] = []
        for ln in lines:
            ln = ln.strip()
            if re.match(r"^\d+\.\s+", ln):
                out.append(ln)
            else:
                # continuação do item anterior
                if out:
                    out[-1] = (out[-1] + " " + ln).strip()
                else:
                    out.append(ln)
        return "\n".join(out)

    # bloco com linhas muito “estruturais” (ex.: cabeçalho das partes)
    # Mantém por linha, mas tenta juntar continuação óbvia (linhas em ALL CAPS quebradas)
    if sum(1 for ln in lines if ":" in ln) >= 2 or any(
        _is_all_caps_like(ln) for ln in lines[:3]
    ):
        out2: List[str] = []
        for ln in lines:
            ln = ln.strip()
            if not out2:
                out2.append(ln)
                continue
            prev = out2[-1]
            # junta continuação quando a linha anterior NÃO termina com pontuação e a atual parece continuação
            if (
                prev
                and prev[-1] not in ".;:!?)]}"
                and ln
                and ln[0].islower()
                and not re.match(r"^\d+\.\s+", ln)
            ):
                out2[-1] = (prev + " " + ln).strip()
            else:
                out2.append(ln)
        return "\n".join(out2)

    # caso geral: junta tudo como parágrafo
    return " ".join(ln.strip() for ln in lines if ln.strip())


def _reflow_text(text: str) -> str:
    """
    Reflow por blocos (separados por linhas vazias).
    Mantém 1 linha vazia entre blocos.
    """
    raw_lines = [ln.rstrip() for ln in text.split("\n")]

    blocks: List[List[str]] = []
    cur: List[str] = []
    for ln in raw_lines:
        if ln.strip() == "":
            if cur:
                blocks.append(cur)
                cur = []
            else:
                # evita acumular vários vazios
                continue
        else:
            cur.append(ln)
    if cur:
        blocks.append(cur)

    out_blocks: List[str] = []
    for b in blocks:
        b_stripped = [x.strip() for x in b if x.strip()]
        if not b_stripped:
            continue

        # headings isolados
        if len(b_stripped) == 1 and _HEADING_RE.match(b_stripped[0]):
            out_blocks.append(b_stripped[0])
            continue

        # preserva linhas especiais se o bloco for “quase todo estrutural”
        if all(
            _STRUCTURAL_LINE_RE.match(x) or _is_all_caps_like(x) for x in b_stripped[:2]
        ):
            out_blocks.append(_reflow_block(b_stripped))
            continue

        out_blocks.append(_reflow_block(b_stripped))

    return "\n\n".join(out_blocks).strip() + "\n"


# -----------------------------
# Formatação: títulos (negrito) + correção quando ficam “colados”
# -----------------------------

_SECTION_CANON = {
    "ACORDAO": "ACÓRDÃO",
    "RELATORIO": "RELATÓRIO",
}

# 1) Quando o título aparece no meio de uma linha (ex.: "... provido. ACÓRDÃO Vistos...")
_SECTION_GLUE_RE = re.compile(
    r"(?m)([^\n])\s+(EMENTA|ACÓRDÃO|ACORDAO|RELATÓRIO|RELATORIO|VOTO)\b"
)

# 2) Quando o título está no começo da linha (podendo ter texto depois na mesma linha)
_SECTION_LINE_RE = re.compile(
    r"(?m)^(EMENTA|ACÓRDÃO|ACORDAO|RELATÓRIO|RELATORIO|VOTO|ATUAÇÃO|AGRAVO INTERNO|TERMO)\b[ \t]*(.*)$"
)


def _format_section_headings(text: str) -> str:
    # isola títulos colados no fim do parágrafo anterior
    text = _SECTION_GLUE_RE.sub(r"\1\n\n\2", text)

    # coloca em negrito e garante quebra após o título se houver resto na mesma linha
    def _repl(m: re.Match) -> str:
        h = m.group(1).strip()
        rest = m.group(2).strip()
        canon = _SECTION_CANON.get(h, h)
        if rest:
            return f"**{canon}**\n\n{rest}"
        return f"**{canon}**"

    return _SECTION_LINE_RE.sub(_repl, text)


def clean_page_text(raw_page_text: str) -> str:
    """
    Pipeline de limpeza por página.
    """
    t = raw_page_text.replace("\r\n", "\n").replace("\r", "\n")
    t = _strip_footer_lines(t)
    t = _fix_label_colon_breaks(t)
    t = _normalize_spaces(t)
    t = _reflow_text(t)
    t = _format_section_headings(t)

    return t


# -----------------------------
# Extração: PyMuPDF (página a página)
# -----------------------------


@dataclass(frozen=True)
class ExtractionMeta:
    pages_total: int
    primary_tool: str = "pymupdf"
    method: str = "text"


def extract_pages_pymupdf(pdf_path: Path) -> tuple[List[str], ExtractionMeta]:
    doc = fitz.open(pdf_path)
    pages: List[str] = []
    for i in range(doc.page_count):
        page = doc.load_page(i)
        txt = page.get_text("text") or ""
        pages.append(txt)
    meta = ExtractionMeta(pages_total=doc.page_count)
    doc.close()
    return pages, meta


# -----------------------------
# Saída: Markdown com front matter + páginas
# -----------------------------


def _yaml_quote(s: str) -> str:
    # quote simples e segura para YAML
    s = s.replace("\\", "\\\\").replace('"', '"')
    return f'"{s}"'


def build_front_matter(
    *,
    source_pdf: str,
    court: str,
    class_: str,
    relator: str,
    judgment_date: str,
    publication_date: str,
    language: str,
    pages_total: int,
) -> str:
    # Mantém formato compatível com o seu padrão atual.
    # Observação: class_ é sempre quoted porque contém ":"/parênteses etc.
    return (
        "---\n"
        "document_type: base_juridica\n"
        "doc_subtype: jurisprudencia\n"
        f"source_pdf: {source_pdf}\n"
        f"court: {court}\n"
        f"class: {_yaml_quote(class_)}\n"
        f"relator: {_yaml_quote(relator)}\n"
        f"judgment_date: {_yaml_quote(judgment_date)}\n"
        f"publication_date: {_yaml_quote(publication_date)}\n"
        f"language: {language}\n"
        "extraction:\n"
        "  method: text\n"
        f"  pages_total: {pages_total}\n"
        "  pages_ocr: []\n"
        "  pages_empty: []\n"
        "  duplicates_removed: 0\n"
        "  primary_tool: pymupdf\n"
        "  fallback_tool: pdfplumber\n"
        "  fallback_pages: []\n"
        "---\n"
    )


def write_markdown(
    out_path: Path,
    front_matter: str,
    cleaned_pages: List[str],
) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", encoding="utf-8") as f:
        f.write(front_matter)
        f.write("\n")
        for i, page_text in enumerate(cleaned_pages, start=1):
            f.write(f"<!-- PAGE: {i} -->\n")
            f.write(f"[[Pág. {i}]]\n")
            f.write(page_text.rstrip() + "\n\n")


# -----------------------------
# Funções auxiliares para extração de metadados
# -----------------------------

MONTHS_PT = {
    "janeiro": "01",
    "fevereiro": "02",
    "março": "03",
    "abril": "04",
    "maio": "05",
    "junho": "06",
    "julho": "07",
    "agosto": "08",
    "setembro": "09",
    "outubro": "10",
    "novembro": "11",
    "dezembro": "12",
}


def parse_publication_date_from_filename(stem: str) -> Optional[str]:
    # Ex.: AIRESP-2038444-2024-06-12 -> 2024-06-12
    m = re.search(r"(\d{4}-\d{2}-\d{2})$", stem)
    return m.group(1) if m else None


def parse_relator_from_text(text: str) -> str:
    m = re.search(r"(?im)^RELATOR\s*:\s*(.+)", text)
    return m.group(1).strip() if m else "NÃO INFORMADO"


def parse_class_from_text(text: str) -> str:
    # Assume que a classe está no início do documento ou numa linha específica
    # Esta é uma simplificação. A implementação original pode ser mais robusta.
    lines = [line.strip() for line in text.split("\n") if line.strip()]
    if lines:  # Tenta pegar a primeira linha não vazia como classe
        return lines[0]
    return "NÃO INFORMADO"


def parse_judgment_date_from_text(text: str) -> str:
    # "Brasília, 10 de junho de 2024."
    m = re.search(
        r"Brasília,\s*(\d{1,2})\s+de\s+([a-zç]+)\s+de\s+(\d{4})",
        text,
        flags=re.IGNORECASE,
    )
    if m:
        day = int(m.group(1))
        mon = MONTHS_PT.get(m.group(2).lower())
        year = m.group(3)
        if mon:
            return f"{year}-{mon}-{day:02d}"
    return ""  # Retorna vazio se não encontrar


def detect_court(text: str) -> str:
    if "Superior Tribunal de Justiça" in text or "STJ" in text:
        return "STJ"
    return "NÃO INFORMADO"


# Carrega rules.py do mesmo diretório, sem depender de import relativo/pacote
import importlib.util
import sys
from pathlib import Path

from pipelines.ingest.pdf_convert.core.engine import EngineIO, EngineMove, run_batch

_RULES_PATH = Path(__file__).with_name("rules.py")
_RULES_MODNAME = f"{__name__}__rules"

_spec = importlib.util.spec_from_file_location(_RULES_MODNAME, _RULES_PATH)
_rules_mod = importlib.util.module_from_spec(_spec)  # type: ignore[arg-type]
sys.modules[_RULES_MODNAME] = _rules_mod
assert _spec is not None and _spec.loader is not None
_spec.loader.exec_module(_rules_mod)

RULES = _rules_mod.RULES


def main_processing_loop() -> None:
    io = EngineIO(
        dir_pdf=Path(DIR_PDF),
        dir_md=Path(DIR_MD),
        dir_json=Path(DIR_JSON),
        dir_rep=Path(DIR_REP),
    )

    # se o run.py estiver injetando limit em algum global, aceitamos; senão, None
    limit = globals().get("LIMIT") or globals().get("limit") or None

    run_batch(
        io=io,
        pdf_files=pdf_files,
        rules=RULES,
        extract_pages=extract_pages_pymupdf,
        limit=limit,
        mover=EngineMove(success_dir=None, fail_dir=None),
    )
