#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Dict, List, Optional


@dataclass(frozen=True)
class ExtractionMeta:
    pages_total: int
    primary_tool: str = "pymupdf"
    method: str = "text"


@dataclass(frozen=True)
class Evidence:
    page: Optional[int]
    snippet: str


class STJRules:
    """
    Regras (modelo) para Base Jurídica — Jurisprudência STJ.
    - Limpeza/normalização por página
    - Extração de metadados (court, class, relator, datas)
    - Construção de front matter (string YAML e dict JSON)
    - Relatório simples (markdown)
    """

    # -----------------------------
    # Padrões STJ (rodapé / assinatura)
    # -----------------------------
    _FOOTER_START_RE = re.compile(
        r"^\s*Documento\s+eletrônico\s+VDA[0-9A-Z]+\b", re.IGNORECASE
    )
    _FOOTER_LINE_RE = re.compile(
        r"^\s*(?:"
        r"Documento\s+eletrônico\s+VDA[0-9A-Z]+\b.*|"
        r"Signatário\(a\)\s*:\s*.*|"
        r"Assinado\s+em\s*:\s*.*|"
        r"Código\s+de\s+Controle\s+do\s+Documento\s*:\s*.*"
        r")\s*$",
        re.IGNORECASE,
    )
    _FOOTER_SITE_CERT_RE = re.compile(
        r"Documento\s*:\s*\d+\s*-\s*Inteiro\s+Teor\s+do\s+Ac[oó]rd[aã]o\s*-\s*Site\s+certificado\s*-\s*DJe\s*:\s*\d{1,2}/\d{1,2}/\d{4}",
        re.IGNORECASE,
    )
    _FOOTER_PAGE_RE = re.compile(
        r"Página\s*\d+\s*de\s*\d+",
        re.IGNORECASE,
    )

    # -----------------------------
    # Padrões STJ (cabeçalho)
    # -----------------------------
    # Labels principais do cabeçalho STJ (inclui RELATORA)
    _LABELS = (
        "RELATOR",
        "RELATORA",
        "AGRAVANTE",
        "AGRAVADO",
        "ADVOGADO",
        "ADVOGADOS",
        "OUTRO NOME",
        "RECORRENTE",
        "RECORRIDO",
        "ASSUNTO",
        "PRESIDENTE DA SESSÃO",
        "SECRETÁRIO",
    )

    # Labels adicionais comuns (para “corte” do relator em cabeçalho na mesma linha)
    _CUT_LABELS = (
        "AGRAVANTE",
        "AGRAVADO",
        "ADVOGADO",
        "ADVOGADOS",
        "RECORRENTE",
        "RECORRIDO",
        "EMBARGANTE",
        "EMBARGADO",
        "APELANTE",
        "APELADO",
        "AUTOR",
        "RÉU",
        "RÉ",
        "IMPETRANTE",
        "IMPETRADO",
        "PACIENTE",
        "ORIGEM",
        "INTERESSADO",
        "INTERESSADA",
        "REQUERENTE",
        "REQUERIDO",
        "REQUERIDA",
        "EXEQUENTE",
        "EXECUTADO",
        "EXECUTADA",
        "RECORRIDO(A)",
        "RECORRENTE(A)",
        "RELATOR",  # não deve cortar dentro do relator, mas mantém compatibilidade
        "RELATORA",
        "ASSUNTO",
        "PRESIDENTE DA SESSÃO",
        "SECRETÁRIO",
    )

    _LABEL_JOIN_RE = re.compile(
        r"(?m)^\s*(" + "|".join(re.escape(x) for x in _LABELS) + r")\s*\n\s*:\s*",
        flags=re.IGNORECASE,
    )

    _RELATOR_LINE_RE = re.compile(r"(?im)\b(RELATORA?)\s*:\s*(.+)$")

    _RELATOR_CUT_RE = re.compile(
        r"\b(" + "|".join(re.escape(x) for x in _CUT_LABELS) + r")\s*:\s*",
        flags=re.IGNORECASE,
    )

    # headings curtas que devem manter quebra (uma linha só)
    _HEADING_RE = re.compile(
        r"^(EMENTA|ACÓRDÃO|RELATÓRIO|VOTO|É\s+O\s+VOTO|TERMO|TERMO DE JULGAMENTO|AUTUAÇÃO|AGRAVO INTERNO)\s*$",
        re.IGNORECASE,
    )

    # linhas “estruturais” (não reflow agressivo)
    _STRUCTURAL_LINE_RE = re.compile(
        r"^(?:\[\[Pág\.\s*\d+\]\]|AgInt\b|REsp\b|AREsp\b|AGRAVO\b|EMBARGOS\b|\(|\d+\.)",
        re.IGNORECASE,
    )

    # Canonização de títulos (casos sem acento)
    _SECTION_CANON = {
        "ACORDAO": "ACÓRDÃO",
        "RELATORIO": "RELATÓRIO",
    }

    # 1) Quando o título aparece “colado” no meio/fim de linha
    _SECTION_GLUE_RE = re.compile(
        r"(?m)([^\n])\s+(EMENTA|ACÓRDÃO|ACORDAO|RELATÓRIO|RELATORIO|VOTO|É\s+O\s+VOTO|ATUAÇÃO|ATUAÇAO|TERMO DE JULGAMENTO|AGRAVO INTERNO)\b"
    )

    # 2) Quando o título está no começo da linha (podendo ter texto depois)
    _SECTION_LINE_RE = re.compile(
        r"(?m)^(EMENTA|ACÓRDÃO|ACORDAO|RELATÓRIO|RELATORIO|VOTO|É\s+O\s+VOTO|ATUAÇÃO|ATUAÇAO|TERMO DE JULGAMENTO|AUTUAÇÃO|TERMO)\b[ \t]*(.*)$"
    )

    # Meses em PT (chaves SEM acento; normalização remove acentos)
    MONTHS_PT = {
        "janeiro": "01",
        "fevereiro": "02",
        "marco": "03",
        "abril": "04",
        "maio": "05",
        "junho": "06",
        "julho": "07",
        "agosto": "08",
        "setembro": "09",
        "outubro": "10",
        "novembro": "11",
        "dezembro": "12",
    }

    # DJe (publication_date no texto RAW)
    _DJE_RE = re.compile(r"\bDJe\s*:\s*(\d{1,2}/\d{1,2}/\d{4})\b", re.IGNORECASE)

    # Julgamento (Brasília/Brasilia com variações DF) — textual e numérico
    _BRASILIA_TEXTUAL_DATE_RE = re.compile(
        r"\bBras[ií]lia"
        r"(?:\s*[-–]\s*DF|\s*\(\s*DF\s*\)|\s*,\s*DF)?"
        r"\s*[,–-]?\s*"
        r"(\d{1,2})\s+de\s+([A-Za-zÀ-ÿçÇ]+)\s+de\s+(\d{4})\b",
        re.IGNORECASE,
    )
    _BRASILIA_NUMERIC_DATE_RE = re.compile(
        r"\bBras[ií]lia"
        r"(?:\s*[-–]\s*DF|\s*\(\s*DF\s*\)|\s*,\s*DF)?"
        r"\s*[,–-]?\s*"
        r"(\d{1,2})[./-](\d{1,2})[./-](\d{4})\b",
        re.IGNORECASE,
    )

    def __init__(
        self,
        *,
        document_type: str = "base_juridica",
        doc_subtype: str = "jurisprudencia",
        language: str = "pt-BR",
    ) -> None:
        self.document_type = document_type
        self.doc_subtype = doc_subtype
        self.language = language

    # -----------------------------
    # Utilitários
    # -----------------------------
    @staticmethod
    def _yaml_quote(s: str) -> str:
        s = (s or "").replace("\\", "\\\\").replace('"', '\\"')
        return f'"{s}"'

    @staticmethod
    def _normalize_newlines(text: str) -> str:
        return (text or "").replace("\r\n", "\n").replace("\r", "\n")

    @staticmethod
    def _normalize_spaces(text: str) -> str:
        lines = [(ln or "").rstrip() for ln in (text or "").split("\n")]
        return "\n".join(lines)

    @staticmethod
    def _is_all_caps_like(s: str) -> bool:
        s2 = re.sub(r"[^A-Za-zÀ-ÿÇÁÉÍÓÚÂÊÔÃÕÜ]", "", s or "")
        if not s2:
            return False
        return s2.upper() == s2 and len(s2) >= 4

    @staticmethod
    def _strip_accents(s: str) -> str:
        if not s:
            return ""
        return "".join(
            c
            for c in unicodedata.normalize("NFD", s)
            if unicodedata.category(c) != "Mn"
        )

    @staticmethod
    def _dmy_to_iso(dmy: str) -> str:
        try:
            dt = datetime.strptime(dmy, "%d/%m/%Y")
            return dt.strftime("%Y-%m-%d")
        except ValueError:
            return ""

    # -----------------------------
    # Limpeza: rodapé + quebras
    # -----------------------------
    def _strip_footer_lines(self, raw: str) -> str:
        text = self._normalize_newlines(raw)
        lines = text.split("\n")

        cut_idx: Optional[int] = None
        for i, ln in enumerate(lines):
            if self._FOOTER_START_RE.match(ln):
                cut_idx = i
                break
        if cut_idx is not None:
            lines = lines[:cut_idx]

        cleaned: List[str] = []
        for ln in lines:
            # remove rodapé mesmo quando vem colado no fim da linha
            ln2 = self._FOOTER_SITE_CERT_RE.sub("", ln)
            ln2 = self._FOOTER_PAGE_RE.sub("", ln2)

            # remove linhas inteiras de assinatura/controle
            if self._FOOTER_LINE_RE.match(ln2):
                continue

            ln2 = ln2.strip()
            if not ln2:
                continue

            cleaned.append(ln2)

        return "\n".join(cleaned)

    def _fix_label_colon_breaks(self, text: str) -> str:
        return self._LABEL_JOIN_RE.sub(lambda m: f"{m.group(1).upper()} : ", text or "")

    def _reflow_block(self, lines: List[str]) -> str:
        if not lines:
            return ""
        if len(lines) == 1:
            return lines[0]

        # bloco contém lista numerada
        if any(re.match(r"^\d+\.\s+", ln) for ln in lines):
            out: List[str] = []
            for ln in lines:
                ln = ln.strip()
                if re.match(r"^\d+\.\s+", ln):
                    out.append(ln)
                else:
                    if out:
                        out[-1] = (out[-1] + " " + ln).strip()
                    else:
                        out.append(ln)
            return "\n".join(out)

        # bloco estrutural (muitas “labels”)
        if sum(1 for ln in lines if ":" in ln) >= 2 or any(
            self._is_all_caps_like(ln) for ln in lines[:3]
        ):
            out2: List[str] = []
            for ln in lines:
                ln = ln.strip()
                if not out2:
                    out2.append(ln)
                    continue
                prev = out2[-1]
                if (
                    prev
                    and prev[-1] not in ".;:!?)]}"
                    and ln
                    and ln[0].islower()
                    and not re.match(r"^\d+\.\s+", ln)
                ):
                    out2[-1] = (prev + " " + ln).strip()
                else:
                    out2.append(ln)
            return "\n".join(out2)

        # caso geral: junta tudo como parágrafo
        return " ".join(ln.strip() for ln in lines if ln.strip())

    def _reflow_text(self, text: str) -> str:
        raw_lines = [(ln or "").rstrip() for ln in (text or "").split("\n")]

        blocks: List[List[str]] = []
        cur: List[str] = []
        for ln in raw_lines:
            if ln.strip() == "":
                if cur:
                    blocks.append(cur)
                    cur = []
                else:
                    continue
            else:
                cur.append(ln)
        if cur:
            blocks.append(cur)

        out_blocks: List[str] = []
        for b in blocks:
            b_stripped = [x.strip() for x in b if x.strip()]
            if not b_stripped:
                continue

            # headings isolados
            if len(b_stripped) == 1 and self._HEADING_RE.match(b_stripped[0]):
                out_blocks.append(b_stripped[0])
                continue

            # preserva linhas especiais se o bloco for “quase todo estrutural”
            if all(
                self._STRUCTURAL_LINE_RE.match(x) or self._is_all_caps_like(x)
                for x in b_stripped[:2]
            ):
                out_blocks.append(self._reflow_block(b_stripped))
                continue

            out_blocks.append(self._reflow_block(b_stripped))

        return ("\n\n".join(out_blocks).strip() + "\n") if out_blocks else "\n"

    def _format_section_headings(self, text: str) -> str:
        text = self._SECTION_GLUE_RE.sub(r"\1\n\n\2", text or "")

        def _repl(m: re.Match) -> str:
            h = (m.group(1) or "").strip()
            rest = (m.group(2) or "").strip()
            canon = self._SECTION_CANON.get(h, h)
            if rest:
                return f"**{canon}**\n\n{rest}"
            return f"**{canon}**"

        return self._SECTION_LINE_RE.sub(_repl, text)

    def clean_page_text(self, raw_page_text: str) -> str:
        t = self._normalize_newlines(raw_page_text)
        t = self._strip_footer_lines(t)  # remove rodapé (inclui DJe em muitos casos)
        t = self._fix_label_colon_breaks(t)  # corrige quebra de "LABEL \n :"
        t = self._normalize_spaces(t)
        t = self._reflow_text(t)
        t = self._format_section_headings(t)
        return t

    def strip_repeated_header_block(self, page_text: str) -> str:
        """
        Remove o cabeçalho repetido típico do STJ no topo da página.
        Use apenas nas páginas 2+ (a primeira página costuma ser útil manter).
        """
        txt = self._normalize_newlines(page_text or "")
        lines = txt.split("\n")

        # se não tem "RELATOR/RELATORA" no topo, não mexe
        top = "\n".join(lines[:25])
        if not re.search(r"(?im)^\s*RELATORA?\s*:\s*", top):
            return page_text

        # corta a partir do primeiro título de seção (em negrito) ou início “narrativo”
        for i, ln in enumerate(lines):
            s = (ln or "").strip()

            if re.match(r"(?i)^\*\*(EMENTA|ACÓRDÃO|RELATÓRIO|VOTO|TERMO)\*\*$", s):
                return "\n".join(lines[i:]).lstrip() + "\n"

            if re.match(r"(?i)^(O\s+EXMO\.|Trata-se|Cuida-se|Vistos)", s):
                return "\n".join(lines[i:]).lstrip() + "\n"

        return page_text

    # -----------------------------
    # Metadados
    # -----------------------------
    @staticmethod
    def parse_publication_date_from_filename(stem: str) -> Optional[str]:
        m = re.search(r"(\d{4}-\d{2}-\d{2})$", stem or "")
        return m.group(1) if m else None

    def parse_relator_from_text(self, text: str) -> str:
        """
        Aceita RELATOR e RELATORA.
        Se vier na mesma linha com outras labels, corta no primeiro label seguinte.
        """
        txt = text or ""
        m = self._RELATOR_LINE_RE.search(txt)
        if not m:
            return "NÃO INFORMADO"

        rel = (m.group(2) or "").strip()
        if not rel:
            return "NÃO INFORMADO"

        # Se houver outras labels no mesmo trecho, corta no primeiro "LABEL :"
        # Ex.: "MINISTRA X AGRAVANTE : Y ..." -> mantém só "MINISTRA X"
        cut = self._RELATOR_CUT_RE.search(rel)
        if cut:
            rel = rel[: cut.start()].strip()

        # Normalização final
        rel = re.sub(r"\s{2,}", " ", rel).strip(" -–—\t")
        return rel if rel else "NÃO INFORMADO"

    @staticmethod
    def parse_class_from_text(text: str) -> str:
        lines = [line.strip() for line in (text or "").split("\n") if line.strip()]
        if not lines:
            return "NÃO INFORMADO"

        first = lines[0]

        # Corta a classe quando começar algum "LABEL :"
        # Ex.: "... (2010/...) RELATOR : MINISTRO ..." -> fica só até antes de RELATOR
        cut = STJRules._RELATOR_CUT_RE.search(first)
        if cut:
            first = first[: cut.start()].strip()

        return first if first else "NÃO INFORMADO"

    def parse_judgment_date_from_text(self, text: str) -> str:
        """
        Aceita variações comuns:
        - Brasília, 21 de agosto de 2018
        - Brasília-DF, 28 de maio de 2019 (Data do Julgamento)
        - Brasília (DF), 28 de maio de 2019
        - Brasilia, 21 de agosto de 2018
        - Brasília, 21/08/2018
        """
        txt = text or ""

        m = self._BRASILIA_TEXTUAL_DATE_RE.search(txt)
        if m:
            day = int(m.group(1))
            mon_raw = self._strip_accents((m.group(2) or "").lower())
            year = m.group(3)
            mon = self.MONTHS_PT.get(mon_raw)
            if mon:
                return f"{year}-{mon}-{day:02d}"

        m2 = self._BRASILIA_NUMERIC_DATE_RE.search(txt)
        if m2:
            day = int(m2.group(1))
            mon = int(m2.group(2))
            year = m2.group(3)
            if 1 <= day <= 31 and 1 <= mon <= 12:
                return f"{year}-{mon:02d}-{day:02d}"

        return ""

    def parse_publication_date_from_text(self, raw_text: str) -> str:
        """
        Extrai DJe do texto RAW.
        Estratégia:
        - coleta todos os DJe
        - dá preferência a linhas com 'Documento'/'Site certificado' (rodapé repetido)
        - escolhe a data com maior pontuação total
        """
        raw = raw_text or ""
        lines = self._normalize_newlines(raw).split("\n")

        candidates: List[tuple[str, int]] = []
        for ln in lines:
            m = self._DJE_RE.search(ln)
            if not m:
                continue
            dmy = m.group(1)
            weight = 1
            lnl = ln.lower()
            if "documento" in lnl:
                weight += 3
            if "site certificado" in lnl:
                weight += 3
            if "inteiro teor" in lnl:
                weight += 1
            candidates.append((dmy, weight))

        if not candidates:
            return ""

        score: Dict[str, int] = {}
        for dmy, w in candidates:
            score[dmy] = score.get(dmy, 0) + w

        best_dmy = max(score.items(), key=lambda kv: kv[1])[0]
        return self._dmy_to_iso(best_dmy)

    @staticmethod
    def detect_court(text: str) -> str:
        if "Superior Tribunal de Justiça" in (text or "") or "STJ" in (text or ""):
            return "STJ"
        return "NÃO INFORMADO"

    def extract_metadata(
        self,
        *,
        full_text: str,
        stem: str,
        raw_full_text: Optional[str] = None,
    ) -> Dict[str, str]:
        """
        Dois fluxos:
        - full_text: texto limpo (para MD/estrutura e extrações gerais)
        - raw_full_text: texto bruto (para capturar DJe/rodapé)
        """
        court = self.detect_court(full_text)
        class_ = self.parse_class_from_text(full_text)
        relator = self.parse_relator_from_text(full_text)

        judgment_date = self.parse_judgment_date_from_text(full_text)
        if not judgment_date and raw_full_text:
            judgment_date = self.parse_judgment_date_from_text(raw_full_text)

        # publication_date:
        # 1) filename (se existir)
        # 2) DJe do texto RAW (preferencial)
        publication_date = self.parse_publication_date_from_filename(stem) or ""
        if not publication_date:
            publication_date = self.parse_publication_date_from_text(
                raw_full_text or ""
            )

        return {
            "document_type": self.document_type,
            "doc_subtype": self.doc_subtype,
            "court": court,
            "class": class_,
            "relator": relator,
            "judgment_date": judgment_date,
            "publication_date": publication_date,
            "language": self.language,
        }

    # -----------------------------
    # Front matter (MD / JSON)
    # -----------------------------
    def build_front_matter_str(
        self,
        *,
        meta: Dict[str, str],
        pages_total: int,
        source_pdf: str,
        extraction: Optional[ExtractionMeta] = None,
    ) -> str:
        return (
            "---\n"
            f"document_type: {meta.get('document_type', self.document_type)}\n"
            f"doc_subtype: {meta.get('doc_subtype', self.doc_subtype)}\n"
            f"source_pdf: {source_pdf}\n"
            f"court: {meta.get('court', 'NÃO INFORMADO')}\n"
            f"class: {self._yaml_quote(meta.get('class', 'NÃO INFORMADO'))}\n"
            f"relator: {self._yaml_quote(meta.get('relator', 'NÃO INFORMADO'))}\n"
            f"judgment_date: {self._yaml_quote(meta.get('judgment_date', ''))}\n"
            f"publication_date: {self._yaml_quote(meta.get('publication_date', ''))}\n"
            f"language: {meta.get('language', self.language)}\n"
            "extraction:\n"
            f"  method: {(extraction.method if extraction else 'text')}\n"
            f"  pages_total: {pages_total}\n"
            "  pages_ocr: []\n"
            "  pages_empty: []\n"
            "  duplicates_removed: 0\n"
            f"  primary_tool: {(extraction.primary_tool if extraction else 'pymupdf')}\n"
            "  fallback_tool: pdfplumber\n"
            "  fallback_pages: []\n"
            "---\n"
        )

    def build_front_matter_dict(
        self,
        *,
        meta: Dict[str, str],
        pages_total: int,
        source_pdf: str,
        extraction: Optional[ExtractionMeta] = None,
    ) -> Dict:
        return {
            "document_type": meta.get("document_type", self.document_type),
            "doc_subtype": meta.get("doc_subtype", self.doc_subtype),
            "source_pdf": source_pdf,
            "court": meta.get("court", "NÃO INFORMADO"),
            "class": meta.get("class", "NÃO INFORMADO"),
            "relator": meta.get("relator", "NÃO INFORMADO"),
            "judgment_date": meta.get("judgment_date", ""),
            "publication_date": meta.get("publication_date", ""),
            "language": meta.get("language", self.language),
            "extraction": {
                "method": (extraction.method if extraction else "text"),
                "pages_total": pages_total,
                "pages_ocr": [],
                "pages_empty": [],
                "duplicates_removed": 0,
                "primary_tool": (extraction.primary_tool if extraction else "pymupdf"),
                "fallback_tool": "pdfplumber",
                "fallback_pages": [],
            },
        }

    # -----------------------------
    # Report
    # -----------------------------
    @staticmethod
    def build_report_markdown(
        *, fname: str, fm_dict: Dict, pages_total: int, primary_tool: str
    ) -> str:
        report = f"# Relatório de Processamento - {fname}\n\n"
        report += "## Metadados Extraídos\n"
        for k, v in fm_dict.items():
            if k != "extraction":
                report += f"- {k}: {v}\n"
        report += "\n## Status de Extração\n"
        report += f"- Total de páginas: {pages_total}\n"
        report += f"- Ferramenta primária: {primary_tool}\n"
        report += "- Páginas limpas e convertidas com sucesso.\n"
        return report

    @staticmethod
    def now_utc_iso_z() -> str:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


# Export padrão esperado pelo conversor
RULES = STJRules()
